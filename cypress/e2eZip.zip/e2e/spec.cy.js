describe('Testing Automation RFMS',()=>{ 
  let sum = undefined;
  it('RFMS',() =>{
      cy.visit('https://iamuat.zims.in:8081//Identity/Account/Login?ReturnUrl=https://rfms-uat.zims.in:13254/&AppName=rfms');

      cy.get('#Input_SewadarId').type('BH0011LB6735');
      cy.get('#Input_Password').type('Rssb@12345');


      cy.get('.captcha-style').then(()=>{
          sum = Cypress.$('.captcha-style').text()
          sum = eval(sum);
          console.log(sum);

          cy.get('#DNT_CaptchaInputText').type(sum);
          cy.get('.btn').click().wait(2000);
      });
      cy.get('#app-menu-button').click();
      cy.get('.MuiList-root > [tabindex="0"]').click();
      
      cy.get('[name="master"]').click().clear().type('MAHARAJ CHARAN SINGH JI').type("{downarrow}").type("{enter}");

      cy.get('#initiationmonth').click();

      cy.get('[name="initiationyear"]').click().type('1950');

      cy.get('[style="font-weight: bold; color: red;"]').should('have.text','Please enter valid year');

      cy.get('[name="initiationyear"]').click().clear().type('1960');
      
      cy.get('#initiationmonth').click();

      cy.get('[style="font-weight: bold; color: red;"]').should('not.exist');

      cy.get('[name="initiationyear"]').click().clear().type('1991');

      cy.get('#initiationmonth').click();

      cy.get('[style="font-weight: bold; color: red;"]').should('have.text','Please enter valid year');
    })

  })